/* <<< Release Notice for library >>> */

#include <projects.h>

char const pj_release[]="Rel. 4.9.1, 04 March 2015";

const char *pj_get_release()

{
    return pj_release;
}
